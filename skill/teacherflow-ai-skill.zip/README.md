# TeacherFlow AI Skill

This ZIP contains the portable TeacherFlow teaching skill. Upload it only where your AI provider supports custom skills. Availability and prerequisites vary by account and plan.

If skill upload is unavailable, paste QUICK-START-PROMPT.md into a normal AI chat. ChatGPT Free users can also use CHATGPT-INSTRUCTIONS.md in Custom Instructions.
